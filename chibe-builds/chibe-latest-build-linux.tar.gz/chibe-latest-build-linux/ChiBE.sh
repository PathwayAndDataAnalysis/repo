java -jar -da -Xmx2048M ChiBE_linux64.jar
